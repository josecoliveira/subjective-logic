class HyperopinionInterface:
    pass
