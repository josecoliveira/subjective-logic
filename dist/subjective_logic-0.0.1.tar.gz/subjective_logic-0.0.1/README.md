# Subjective Logic Python Library


## References

Audun Jøsang. “Categories of Belief Fusion”. In: _Journal of Advances in Information Fusion_ 13.2 (2018), pp. 235–254.

Audun  Jøsang. _Subjective  Logic  -  A  Formalism  for  Reasoning  Under  Uncertainty_. Artificial Intelligence: Foundations, Theory, and Algorithms. Springer, 2016
